import React from 'react';
import { View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';
import { useNavigation, useRoute } from '@react-navigation/native';

const ProfileScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  const { imageUri } = route.params || {};

  // Local images
  const localImages = {
    Monday: require('./assets/monday.png'),
    Tuesday: require('./assets/tuesday.png'),
    Wednesday: require('./assets/wednesday.png'),
    Thursday: require('./assets/thursday.png'),
    Friday: require('./assets/friday.png'),
  };

  // Profile image path
  const profileImage = require('./assets/jasmin.png'); // Update this to match your file name

  return (
    <View style={styles.container}>
      <View style={styles.profileHeader}>
        <Image
          source={imageUri ? { uri: imageUri } : profileImage}
          style={styles.profileImage}
        />
        <Text style={styles.username}>@Jasmin</Text>
      </View>
      <Text style={styles.galleryTitle}>Myntra Look Gallery</Text>
      <View style={styles.calendar}>
        <View style={styles.day}>
          <TouchableOpacity
            style={styles.createLookButton}
            onPress={() => navigation.navigate('SelectPhoto')}
          >
            <Text style={styles.createLookText}>+ Create Today's Look</Text>
          </TouchableOpacity>
          <Text style={styles.dayText}>Sunday</Text>
        </View>
        {Object.keys(localImages).map((day, index) => (
          <View key={index} style={styles.day}>
            <Image source={localImages[day]} style={styles.dayImage} />
            <Text style={styles.dayText}>{day}</Text>
          </View>
        ))}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#fff',
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
  },
  username: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: 'bold',
  },
  galleryTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  createLookButton: {
    backgroundColor: '#f0f0f0',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
    alignItems: 'center',
  },
  createLookText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  calendar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  day: {
    width: '30%',
    alignItems: 'center',
    marginBottom: 10, // Adjust this to reduce the gap
  },
  dayImage: {
    width: '100%', // Use percentage to fit within the day container
    height: 100,   // Adjust height as needed
    resizeMode: 'cover', // Ensure image covers the container without stretching
    marginBottom: 5,  // Reduce the margin if needed
  },
  dayText: {
    fontSize: 16,
    fontWeight: 'bold',
  },
});

export default ProfileScreen;
